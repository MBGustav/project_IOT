#include "nrf52833.h"
#include <stdbool.h>
#include <stdio.h>
#include "i2c_cmd.h"

/*
sources:
    https://github.com/elecfreaks/pxt-Cutebot-Pro/blob/master/main.ts
I2C:
    same a Cutebot
*/






int main(void)
{
    sonar_init();
    float dist =-1;
    while (1) {
        dist = get_sonar_distance_cm(3000);
        printf("Dist %i\n", (int) dist);
        if(dist == -1.0)  printf("minus 1\n");
        if(dist < 10.0f)  printf("Distance < 10:   %i\n", (int) dist);
        if(dist >= 10.0f) printf("Distance >= 10:  %i\n", (int) dist);
    }

}

