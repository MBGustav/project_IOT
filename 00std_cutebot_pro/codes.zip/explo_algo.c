#include <stdio.h>
#include <stlib.h>

#include "i2c_cmd.h" //i2c cmds


#define MAP_GRID_SIZE (10)
#define  CELL_CM (10)

// squared map to consider.
typedef enum {
    NORTH =0,
    EAST  =1,
    SOUTH =2,
    WEST  =3
} heading_t;


//Original data from Robot
int robot_pos_x = 0;
int robot_pos_y = 0;
heading_t robot_heading = NORTH;




typedef enum field_t{
  unknown,
  explored, 
  occuppied
}field_t;

field_t global_map[MAP_GRID_SIZE][MAP_GRID_SIZE];

void map_init();
void mark_field(int coord_x, int coord_y, field_t field );
field_t get_field(int coord_x, int coord_y);
void mark_field(int coord_x, int coord_y, field_t field );



void map_init()
{
  for(int i = 0; i < MAP_GRID_SIZE; i++){
    for(int j = 0; j < MAP_GRID_SIZE; j++){
       mark_field(i,j, unknown);
    }
  }
}


void mark_field(int coord_x, int coord_y, field_t field )
{
  //constraint
  if (coord_x < 0 || coord_x >= MAP_GRID_SIZE ) return;
  if (coord_y < 0 || coord_y >= MAP_GRID_SIZE ) return;
  
  global_map[coord_x][coord_y] = field;
}


field_t get_field(int coord_x, int coord_y)
{
  if (coord_x < 0 || coord_x >= MAP_GRID_SIZE ) return -1;
  if (coord_y < 0 || coord_y >= MAP_GRID_SIZE ) return -1;

  return global_map[coord_x][coord_y];
}


void get_next_cell(
    int x,
    int y,
    direction_t dir,
    int* next_x,
    int* next_y)
{
    *next_x = x;
    *next_y = y;

    switch(dir)
    {
        case NORTH:(*next_y)--; break;
        case SOUTH:(*next_y)++; break;
        case EAST: (*next_x)++; break;
        case WEST: (*next_x)--; break;
    }
}


// Rotate vehicle to good direction
void rotate_to(direction_t target)
{
    int diff = target - robot_heading;

    if(diff == 0) return;

    if(diff == 1 || diff == -3)
        cutebot_trolley_steering(CB_TURN_RIGHT, 90);

    else if(diff == -1 || diff == 3)
        cutebot_trolley_steering(CB_TURN_LEFT, 90);

    else
    {
        cutebot_trolley_steering(CB_TURN_LEFT, 180);
    }

    robot_heading = target;
}

void move_one_cell()
{
    cutebot_move_distance(CUTEBOT_FORWARD, CELL_CM);
}

void update_position()
{
    switch(robot_dir)
    {
        case NORTH: robot_y--; break;
        case SOUTH: robot_y++; break;
        case EAST:  robot_x++; break;
        case WEST:  robot_x--; break;
    }
}

void explore_grid(void)
{
    for(int y = 0; y < MAP_GRID_SIZE; y++)
    {
        if(direction == 1)
        {
            for(int x = 0; x < MAP_GRID_SIZE; x++)
            {
                robot_x = x;
                robot_y = y;

                mark_field(x, y, explored);

                if(check_obstacle_ahead())
                {
                    mark_field(x, y, occuppied);
                    return;
                }

                if(x < MAP_GRID_SIZE - 1)
                    move_one_cell_forward();
            }
        }
        else
        {
            for(int x = MAP_GRID_SIZE - 1; x >= 0; x--)
            {
                robot_x = x;
                robot_y = y;

                mark_field(x, y, explored);

                if(check_obstacle_ahead())
                {
                    mark_field(x, y, occuppied);
                    return;
                }

                if(x > 0)
                    move_one_cell_forward();
            }
        }

        // muda direção (serpentina)
        direction *= -1;

        // sobe uma linha
        if(y < MAP_GRID_SIZE - 1)
        {
            cutebot_trolley_steering(CB_TURN_RIGHT, 90);
            move_one_cell_forward();
            cutebot_trolley_steering(CB_TURN_RIGHT, 90);
        }
    }
}