#include <stdbool.h>


#define OBSTACLE_DIST_EXPECTED (10)



void timer1_init(void)
{
    NRF_TIMER1->TASKS_STOP = 1;
    NRF_TIMER1->MODE = 0;        // Timer
    NRF_TIMER1->BITMODE = 3;     // 32-bit
    NRF_TIMER1->PRESCALER = 4;   // 1 MHz → 1 µs
}

void sonar_init() {
    // Configura P8 (P0.10) como Saída para o Trigger
    NRF_P0->PIN_CNF[10] = (1 << 0); 

    // Configura P12 (P0.12) como Entrada para o Echo
    // Importante: Sem pull-up, pois o sensor envia 5V (o Cutebot Pro regula para 3.3V)
    NRF_P0->PIN_CNF[12] = (0 << 0); 
    timer1_init();
}


static void sonar_trigger(void) {
    NRF_P0->OUTCLR = (1 << 10); // Garante nível baixo (P8)
    for (volatile int i = 0; i < 100; i++); 

    NRF_P0->OUTSET = (1 << 10); // Pulso HIGH
    for (volatile int i = 0; i < 160; i++); 

    NRF_P0->OUTCLR = (1 << 10); // Volta para LOW
}

float get_sonar_distance_cm(uint32_t timeout_us) {
    sonar_trigger();

    NRF_TIMER1->TASKS_CLEAR = 1;
    NRF_TIMER1->TASKS_START = 1;

    // 1. Espera o pino Echo (P0.12) ficar HIGH
    while (!(NRF_P0->IN & (1 << 12))) {
        NRF_TIMER1->TASKS_CAPTURE[0] = 1; // Copia tempo atual para CC[0]
        if (NRF_TIMER1->CC[0] > timeout_us) {
            NRF_TIMER1->TASKS_STOP = 1;
            return -1.0f;
        }
    }

    // Reseta o timer no início do pulso HIGH para medir a duração
    NRF_TIMER1->TASKS_CLEAR = 1;

    // 2. Mede enquanto o pino Echo (P0.12) estiver HIGH
    while (NRF_P0->IN & (1 << 12)) {
        NRF_TIMER1->TASKS_CAPTURE[0] = 1;
        if (NRF_TIMER1->CC[0] > timeout_us) {
            NRF_TIMER1->TASKS_STOP = 1;
            return -1.0f;
        }
    }

    uint32_t t = NRF_TIMER1->CC[0];
    NRF_TIMER1->TASKS_STOP = 1;

    // Conversão: microssegundos / 58.2 (ou /29.1 / 2) resulta em cm
    return (float)t / 58.0f;
}



bool check_obstacle(void)
{
  int dist = (int) get_sonar_distance_cm(30000);
  
  //if obstacle, add to the grid

  if(dist <= OBSTACLE_DIST_EXPECTED)
  {
    switch(robot_heading){
      case NORTH: area_grid[robot_pos_x+1][robot_pos_y  ]; break;
      case SOUTH: area_grid[robot_pos_x-1][robot_pos_y  ]; break;
      case EAST : area_grid[robot_pos_x  ][robot_pos_y-1]; break;
      case WEST : area_grid[robot_pos_x  ][robot_pos_y+1]; break;
  }
 
//TODO: Implement this function
}